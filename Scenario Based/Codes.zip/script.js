        (function () {
            var STORAGE_KEY = "eventRegistrations";

            function loadRegistrations() {
                try {
                    var raw = localStorage.getItem(STORAGE_KEY);
                    return raw ? JSON.parse(raw) : [];
                } catch (e) {
                    return [];
                }
            }

            function saveRegistrations(list) {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
            }

            function downloadExcel(list) {
                var worksheet = XLSX.utils.json_to_sheet(list);
                var workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, "Registrations");
                worksheet["!cols"] = [
                    { wch: 22 }, // Student Name
                    { wch: 16 }, // Register Number
                    { wch: 28 }, // Department
                    { wch: 26 }, // Email
                    { wch: 30 }, // Event
                    { wch: 20 }  // Registered On
                ];
                XLSX.writeFile(workbook, "Event_Registrations.xlsx");
            }

            function showMessage(text, isError) {
                var box = document.getElementById("formMessage");
                box.textContent = text;
                box.style.display = "block";
                if (isError) {
                    box.style.background = "#fdecea";
                    box.style.color = "#b91c1c";
                    box.style.border = "1px solid #f5c2c0";
                } else {
                    box.style.background = "#e6f4ea";
                    box.style.color = "#1e7a34";
                    box.style.border = "1px solid #b8e2c3";
                }
            }

            var form = document.getElementById("registrationForm");

            form.addEventListener("submit", function (e) {
                e.preventDefault();

                var student = document.getElementById("name").value.trim();
                var registerNo = document.getElementById("regno").value.trim();
                var department = document.getElementById("department").value;
                var email = document.getElementById("email").value.trim();
                var event = document.getElementById("event").value;

                if (!student || !registerNo || !department || !email || !event) {
                    showMessage("Please fill in all fields before submitting.", true);
                    return;
                }

                var record = {
                    "Student Name": student,
                    "Register Number": registerNo,
                    "Department": department,
                    "Email": email,
                    "Event": event,
                    "Registered On": new Date().toLocaleString()
                };

                var registrations = loadRegistrations();
                registrations.push(record);
                saveRegistrations(registrations);

                downloadExcel(registrations);

                showMessage(
                    "Registration successful! Your Excel sheet (Event_Registrations.xlsx) has been downloaded with " +
                    registrations.length + " registration(s).",
                    false
                );

                form.reset();
            });
        })();
